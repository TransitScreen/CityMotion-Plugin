# CityMotion Webview for iOS Integration

**Version 0.5.0**

The `CMWDemoApp` is an XCode production ready demo application that simulates a 
typical partner integration third-party app with the following behavior:

- App opens to a Landing scene (your "home screen" or "directory")
- A button can navigate to the CityMotion Webview scene
- The scene presents itself and loads CityMotion Webview
- A back button is provided to escape back to the previous scene
